# Spectrum Portal (Extended)
Created: 2025-11-02

See `supabase.sql` and `/app/api/*` routes.