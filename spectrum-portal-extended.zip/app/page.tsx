export default function Page(){
  return (<main className="max-w-6xl mx-auto p-8 space-y-4">
    <h1 className="text-3xl font-bold">Sharon Support Spectrum — Operations Portal</h1>
    <p className="text-slate-700">Extended bundle ready.</p>
  </main>)
}