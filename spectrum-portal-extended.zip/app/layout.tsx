import './globals.css'
export const metadata = { title: 'Sharon Support Spectrum Portal', description: 'NDIS operations portal' }
export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="en"><body className="min-h-screen bg-white text-slate-900">{children}</body></html>)
}